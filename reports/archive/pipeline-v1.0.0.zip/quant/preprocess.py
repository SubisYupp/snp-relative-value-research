from pathlib import Path
from collections import Counter
from dataclasses import asdict
import hashlib
import json
import time
import pandas as pd
import numpy as np
from .config import Config,save_json,calendar_split
from .ingestion import read_file
from .cleaning import clean
from .forwards import add_forwards
from .surface import add_surface
from .features import add_lags
from .target import match_horizon

def preprocess(config=Config()):
    raw=sorted([*Path(config.raw_dir).glob('*.parquet'),*Path(config.raw_dir).glob('*.csv')])
    if not raw: raise FileNotFoundError(config.raw_dir)
    Path('data/processed').mkdir(parents=True,exist_ok=True)
    all_reports=[]; market=[]; total=0; start=time.time()
    fingerprint=hashlib.sha256(json.dumps(asdict(config),sort_keys=True).encode()).hexdigest()[:12]
    for i,f in enumerate(raw):
        cache=Path('data/processed')/(f.stem+'.parquet'); meta=cache.with_suffix('.json')
        source_stat=[f.stat().st_size,f.stat().st_mtime_ns]
        if cache.exists() and meta.exists():
            report=json.loads(meta.read_text())
            if report.get('fingerprint')==fingerprint and report.get('source_stat')==source_stat:
                all_reports.append(report); market.extend(report['market']); total+=report['cleaned_rows']; continue
        d,raw_count=read_file(f); d,report=clean(d,config.min_vega)
        d=add_forwards(d); d=add_surface(d,config.surface_neighbors); d=add_lags(d,config.tolerance_minutes)
        d=match_horizon(d,config.horizon_minutes,config.tolerance_minutes)
        m=d.groupby('timestamp',observed=True).agg(underlying=('underlying','median'),atm_iv=('atm_iv','median')).reset_index()
        report.update(raw_rows=raw_count,matched=int(d.target.notna().sum()),horizon_quantiles=d.actual_horizon_minutes.quantile([.05,.5,.95]).to_dict(),horizon_counts=d.actual_horizon_minutes.value_counts().to_dict(),forward_fallback=int(d.forward_fallback.sum()),fingerprint=fingerprint,source_stat=source_stat,market=[{**r,'timestamp':str(r['timestamp'])} for r in m.to_dict('records')],dte_quantiles=d.dte.quantile([0,.05,.5,.95,1]).to_dict(),vega_quantiles=d.vega.quantile([0,.05,.5,.95,1]).to_dict(),strikes_per_expiry=d.groupby('expiry').strike.nunique().to_dict())
        for c in d.select_dtypes('float64'): d[c]=d[c].astype('float32')
        d.to_parquet(cache,index=False); save_json(meta,report)
        all_reports.append(report); market.extend(report['market']); total+=len(d)
        if i%10==0: print(f'Preprocess {i+1}/{len(raw)} | {total:,} options | {time.time()-start:.0f}s',flush=True)
    m=pd.DataFrame(market); m['timestamp']=pd.to_datetime(m.timestamp); m=m.groupby('timestamp',as_index=False).median(numeric_only=True).sort_values('timestamp')
    m.to_parquet('data/processed/market.parquet',index=False)
    agg={k:sum(r[k] for r in all_reports) for k in ['raw_rows','input_option_rows','cleaned_rows','matched','exact_duplicates','duplicate_contract_timestamp','unchanged_consecutive_prices','forward_fallback','iv_above_300pct_retained_flag']}
    for name in ['drops','flags','horizon_counts']:
        values=Counter()
        for r in all_reports: values.update(r[name])
        agg[name]=dict(values)
    fields=all_reports[0]['missing_pct']
    agg['missing_pct']={k:sum(r['missing_pct'].get(k,0)*r['input_option_rows'] for r in all_reports)/agg['input_option_rows'] for k in fields}
    agg['target_match_pct']=100*agg['matched']/agg['cleaned_rows']
    agg['unmatched']=agg['cleaned_rows']-agg['matched']; agg['dropped']=agg['input_option_rows']-agg['cleaned_rows']
    agg['daily']=[{k:r[k] for k in ['raw_rows','cleaned_rows','matched','dte_quantiles','vega_quantiles','strikes_per_expiry']} for r in all_reports]
    agg['source_files']=[str(f) for f in raw]
    save_json('results/metrics/data_quality.json',agg)
    print(f'Preprocessing complete: {total:,} clean options',flush=True)
    return m,agg

if __name__=='__main__': preprocess()
