import numpy as np

def clean(d, min_vega=.01):
    report={'input_option_rows':len(d),'missing_pct':(d.isna().mean()*100).to_dict(),'exact_duplicates':int(d.duplicated().sum()),'duplicate_contract_timestamp':int(d.duplicated(['contract_id','timestamp']).sum())}
    rules={
        'invalid_identity': d.timestamp.isna()|d.expiry.isna()|~d.option_type.isin(['C','P'])|~(d.strike>0),
        'expired': ~(d.dte>0),
        'invalid_price': ~(d.option_price>=0)|~np.isfinite(d.option_price),
        'invalid_underlying': ~(d.underlying>0)|~np.isfinite(d.underlying),
        'invalid_iv': ~(d.iv>0)|~np.isfinite(d.iv),
        'nonpositive_vega': ~(d.vega>0)|~np.isfinite(d.vega),
        'small_positive_vega': (d.vega>0)&(d.vega<min_vega),
        'invalid_delta': ~np.isfinite(d.delta)|(d.delta.abs()>1.001),
    }
    report['flags']={k:int(v.sum()) for k,v in rules.items()}
    report['iv_above_300pct_retained_flag']=int((d.iv>3).sum())
    keep=np.ones(len(d),dtype=bool); drops={}
    for k,mask in rules.items(): drops[k]=int((keep&mask).sum()); keep &= ~mask
    d=d.loc[keep].copy()
    # Conflicting duplicate quotes have no reliable ordering: exclude every duplicate identity.
    duplicate=d.duplicated(['contract_id','timestamp'],keep=False)
    drops['ambiguous_duplicate_rows']=int(duplicate.sum()); d=d.loc[~duplicate].copy()
    d=d.sort_values(['contract_id','timestamp'])
    previous=d.groupby('contract_id',sort=False).option_price.shift()
    report['unchanged_consecutive_prices']=int(d.option_price.eq(previous).sum())
    report['stale_note']='Unchanged consecutive prices are a proxy only; no quote update timestamps exist.'
    report['drops']=drops; report['cleaned_rows']=len(d)
    return d.reset_index(drop=True),report
